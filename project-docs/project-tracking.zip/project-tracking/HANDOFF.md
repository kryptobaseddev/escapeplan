# Project Handoff Template (AI-Friendly)

Use this file to orient any contributor—human or AI—before they touch the project. Replace highlighted placeholders as soon as you know the answers.

## Project Snapshot
| Field | Value |
| ----- | ----- |
| Project name | `REPLACE_WITH_PROJECT_NAME` |
| Primary goal | _e.g. “Launch internal beta with three core flows validated.”_ |
| Current phase | `PHASE_1` |
| Contact / escalation | _Name + preferred channel_ |
| Environments | _Branches, URLs, deployment targets_ |

## Session Flow
### Start-of-session checklist
1. Read the newest session note in `project-docs/project-tracking/sessions/`.
2. Review active tasks in `TODO.json` for the current phase.
3. Cross-check linked user stories to understand acceptance criteria.
4. Run baseline validation:
   ```bash
   ./project-tracker validate
   ```
5. If anything fails, log it in the session note before continuing.

### During the session
- Work only on tasks that match the current phase unless a decision is documented.
- Update task status immediately when progress changes.
- Capture decisions, blockers, or new risks in the session note template.
- Keep commands reproducible—note any extra steps you run.

### End-of-session checklist
1. Update `TODO.json` (status, assignee, notes, timestamps if you track them).
2. Summarize outcomes and next steps in the session note.
3. Re-run `./project-tracker validate` and any project-specific tests.
4. Commit with a descriptive message referencing task/story IDs.
5. Ping the next collaborator with the session summary.

## Setup Pointers
- For **new projects**, fill `project.yaml` then run `./project-tracker init-config --config project-docs/project-tracking/project.yaml`.
- For **existing projects**, audit your docs, update `project.yaml`, rerun the command above, and sanity-check with `./project-tracker quick-check`.
- Tailor `qualityGateRequirements` in `TODO.json` once you know coverage/documentation expectations.

## Command Reference
```bash
# Validate tracker data and configs
./project-tracker validate

# Quick health summary for AI/LLM agents
./project-tracker quick-check

# Start a session note with current context
./project-tracker new-session

# Generate a Markdown report for stakeholders
./project-tracker report markdown
```

Customize or add project-specific commands below once they exist (tests, builds, deployment scripts).

## Incident Basics
Fill these in when the project becomes operational:
- Severity-1 response target: _e.g. “Acknowledge within 15 minutes.”_
- Urgent communication channel: _Slack channel / pager / email_
- Incident log location: _Link or path_

## Metrics to Watch
List 3–5 metrics that prove the project is healthy (throughput, blocker count, uptime, etc.). Update them during retrospectives.

---
Keep this document lean. If a section stops helping, trim or replace it.
